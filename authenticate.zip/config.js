const config ={
    PORT: process.env.PORT ||3000,
   AUTH_SECRET: process.env.AUTH_SECRET || "secret",
}

module.exports = config